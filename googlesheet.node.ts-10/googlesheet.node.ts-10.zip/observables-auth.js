"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getNewToken$ = exports.buildOAuthClientAndSetToken = exports.oAuth2Client$ = void 0;
const googleapis_1 = require("googleapis");
const observables_1 = require("./observables");
const operators_1 = require("rxjs/operators");
const rxjs_1 = require("rxjs");
function oAuth2Client$(credentials, token) {
    // Read client secrets and token from local files.
    return readCredentials$(credentials).pipe(operators_1.concatMap((credentialsJson) => readToken$(token).pipe(operators_1.catchError((err) => {
        if (err.code === "ENOENT" && err.path === token) {
            return getNewToken$(credentialsJson, token);
        }
        throw err;
    }), operators_1.map((tokenJson) => [credentialsJson, tokenJson]))), operators_1.map(([credentialsJson, tokenJson]) => {
        const oAuth2Client = buildOAuthClientAndSetToken(credentialsJson, tokenJson);
        return oAuth2Client;
    }));
}
exports.oAuth2Client$ = oAuth2Client$;
function buildOAuthClientAndSetToken(credentialsJson, tokenJson) {
    const oAuthClient = buildOAuthClient(credentialsJson);
    oAuthClient.setCredentials(tokenJson);
    return oAuthClient;
}
exports.buildOAuthClientAndSetToken = buildOAuthClientAndSetToken;
function readCredentials$(file) {
    return observables_1.readFile$(file).pipe(operators_1.tap({
        error: (err) => console.log("Error reading client secret file:", err),
    }), operators_1.map((credentials) => JSON.parse(credentials.toString())));
}
function readToken$(file) {
    return observables_1.readFile$(file).pipe(operators_1.tap({
        error: (err) => console.log("Error reading token file:", err),
    }), operators_1.map((token) => JSON.parse(token.toString())));
}
// If modifying these scopes, delete token.json.
const SCOPES = ["https://www.googleapis.com/auth/spreadsheets.readonly"];
function getNewToken$(credentials, tokenPath) {
    const oAuth2Client = buildOAuthClient(credentials);
    const authUrl = oAuth2Client.generateAuthUrl({
        access_type: "offline",
        scope: SCOPES,
    });
    console.log("Authorize this app by visiting this url:", authUrl);
    return observables_1.question$("Enter the code from that page here: ").pipe(operators_1.concatMap((code) => retrieveNewToken$(oAuth2Client, code)), operators_1.concatMap((token) => observables_1.writeFile$(tokenPath, JSON.stringify(token)).pipe(operators_1.map(() => token))), operators_1.tap({
        next: () => console.log("Token stored to", tokenPath),
        error: (err) => console.error(`Error while trying to store token on file ${tokenPath}`, err),
    }));
}
exports.getNewToken$ = getNewToken$;
function buildOAuthClient(credentialsJson) {
    const { client_secret, client_id, redirect_uris } = credentialsJson.installed;
    const oAuthClient = new googleapis_1.google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);
    return oAuthClient;
}
function retrieveNewToken$(oAuth2Client, code) {
    return new rxjs_1.Observable((observer) => {
        oAuth2Client.getToken(code, (err, token) => {
            if (err) {
                console.error("Error while trying to retrieve access token", err);
                observer.error(err);
                return;
            }
            observer.next(token);
        });
    });
}
//# sourceMappingURL=observables-auth.js.map